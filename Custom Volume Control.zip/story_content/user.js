function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5hXTZpKXLI0":
        Script1();
        break;
      case "6AVUow0J7fE":
        Script2();
        break;
  }
}

function Script1()
{
  // Define your volume variable (1-10)
var player = GetPlayer();
var volume = player.GetVar("volume"); // Change this to your desired volume level
// Function to adjust the volume of all audio and video elements
function adjustVolume() {
  // Get all audio and video elements on the page
  var mediaElements = document.querySelectorAll('audio, video');

  // Iterate through each media element and set its volume
  mediaElements.forEach(function(element) {
    // Ensure that the volume is within the valid range (0-10)
    volume = Math.max(0, Math.min(10, volume));

    // Convert the volume to a value between 0 and 1 (0.0 to 1.0)
    var adjustedVolume = volume / 10;

    // Set the volume of the element
    element.volume = adjustedVolume;

    // Mute the element if the volume is 0
    element.muted = (volume === 0);
  });
}

// Call the adjustVolume function to set the volume for all media elements
adjustVolume();

}

function Script2()
{
  
var player = GetPlayer();
var volume = player.GetVar("volume"); 

function adjustVolume() {

  var mediaElements = document.querySelectorAll('audio, video');


  mediaElements.forEach(function(element) {

    volume = Math.max(0, Math.min(10, volume));


    var adjustedVolume = volume / 10;


    element.volume = adjustedVolume;


    element.muted = (volume === 0);
  });
}

adjustVolume();

}

